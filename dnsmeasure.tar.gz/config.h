#include <iostream>
#include <string>
//the top 10 domains

static int num_of_domains = 10;
static std::string domains[] = {
    "google.com",
    "facebook.com",
    "youtube.com",
    "yahoo.com",
    "live.com",
    "wikipedia.org",
    "baidu.com",
    "blogger.com",
    "msn.com",
    "qq.com"
};
